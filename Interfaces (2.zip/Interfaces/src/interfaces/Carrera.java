
package interfaces;


public class Carrera 
{
    private String carrera;
    
    public Carrera ()
    {
        
    }

    public Carrera(String carrera) {
        this.setCarrera(carrera);
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getCarrera() {
        return carrera;
    }
            
    
}
