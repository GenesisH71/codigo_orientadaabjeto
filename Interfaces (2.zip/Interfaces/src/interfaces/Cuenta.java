
package interfaces;


public class Cuenta extends Estudiantes
{
   private int ncuenta;

   public Cuenta() 
    {
        
    }
    public Cuenta(int ncuenta) 
    {
        this.setNcuenta(ncuenta);
    }

    public void setNcuenta(int ncuenta) {
        this.ncuenta = ncuenta;
    }

    public int getNcuenta() {
        return this.ncuenta;
    }

    
    
           
}
