
package interfaces;


public class Estudiantes 
{
    private String nombre;
    private String apellido;

    public Estudiantes() 
    {
      
    }
    
    public Estudiantes(String nombre, String apellido) 
    {
      this.setNombre(nombre);
      this.setApellido(apellido);
      
    }

    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }

    public String getNombre() 
    {
        return this.nombre;
    }

    public void setApellido(String apellido) 
    {
        this.apellido = apellido;
    }
    
    public String getApellido() 
    {
        return this.apellido;
    }
    
    
    
}
