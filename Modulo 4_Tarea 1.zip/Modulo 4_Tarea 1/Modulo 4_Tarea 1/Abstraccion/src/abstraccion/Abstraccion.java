
package abstraccion;

import Pais.Canada;
import Pais.Cuba;
import Pais.Nicaragua;


public class Abstraccion 
{

    
    public static void main(String[] args) 
    {
        Nicaragua nicaragua = new Nicaragua();
        Cuba cuba = new Cuba();
        Canada canada = new Canada();
        
        System.out.println("Pais 1");
        nicaragua.getpais();
        nicaragua.getpresidente();
        
        System.out.println("\n"
                + "Pais 2");
        cuba.getpais();
        cuba.getpresidente();
        
        System.out.println("\n"
                + "Pais 3");
        canada.getpais();
        canada.getpresidente();
    }
    
}
