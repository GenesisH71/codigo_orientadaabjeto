
package Pais;

public class Canada extends Pais 
{

    @Override
    public void getpais() 
    {
        System.out.println("Pais: Canada");
    }

    @Override
    public void getpresidente() 
    {
        System.out.println("Presidente(Primer Ministro): Justin Trudeau");
    }
    
}
