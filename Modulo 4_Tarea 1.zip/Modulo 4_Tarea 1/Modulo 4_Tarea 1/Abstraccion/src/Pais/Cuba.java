
package Pais;

public class Cuba extends Pais{

    @Override
    public void getpais() 
    {
        System.out.println("Pais: Cuba");
    }

    @Override
    public void getpresidente() 
    {
        System.out.println("Presidente: Miguel Díaz-Canel");
    }
    
}
