
package Pais;


public abstract class Pais 
{

    public abstract void getpais();
    public abstract void getpresidente();

}