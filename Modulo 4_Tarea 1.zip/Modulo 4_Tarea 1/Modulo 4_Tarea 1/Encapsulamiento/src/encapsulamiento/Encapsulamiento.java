
package encapsulamiento;


public class Encapsulamiento 
{
    private String nombre;
    private int edad;
    private int anos;
    
    public void setnombre(String nom)
    {
        this.nombre = nom;   
    }
    
    public String getnombre()
    {
        return nombre;
    }
    
    public void setedad(int ed)
    {
        this.edad = ed;
    }
    public int getedad()
    {
        return edad;
    }
    
    public void setanos(int an)
    {
        this.anos = an;
    }
    public int getanos()
    {
        return anos;
    }
}
