
package ciudadanoencap;

import encapsulamiento.Encapsulamiento;

public class Ciudadanoencap 
{

  
    public static void main(String[] args) 
    {
        Encapsulamiento ciudadano = new Encapsulamiento();
        
        ciudadano.setnombre("Humberta Valladares");
        System.out.println("Nombre: " + ciudadano.getnombre());
        
        ciudadano.setedad(24);
        System.out.println("Edad: " + ciudadano.getedad());
        
        ciudadano.setanos(7);
        System.out.println("Años de experiencia: " + ciudadano.getanos());
    }
    
}
