
package Formas;


public class Circulo extends Formas
{
    private int radio;
    
    public Circulo()
    {
      super.EstablecerColor("Color: Rojo");   
    }
    public void EstablecerRadio(int rad)
    {
        this.radio = rad;
    }
    
    public int getRadio()
    {
        return radio;
    }
    

    
    /**
     *
     * @return
     */
    @Override
   public String Dibujar() 
    {
        return "Nombre: Circulo";
    }
    
}
