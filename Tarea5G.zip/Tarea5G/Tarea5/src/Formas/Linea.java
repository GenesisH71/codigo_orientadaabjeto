
package Formas;

public class Linea extends Formas
{
    private String largo;
    
    public Linea()
    {
        
    }
    
    public void EstablecerLargo(String lar)
    {
        this.largo =  lar;
    }
    public String getLargo()
    {
        return largo;
    }

    /**
     *
     * @return
     */
    @Override
    public String Dibujar() 
    {
        return "Nombre: Linea";
    }   
}