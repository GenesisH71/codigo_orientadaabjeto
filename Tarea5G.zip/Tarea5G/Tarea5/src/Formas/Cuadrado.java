
package Formas;

public class Cuadrado extends Formas 
{
    private int area;
    
    public Cuadrado()
    {
        EstablecerColor("Color: Naranja");
    }
    
    public void EstablecerArea(int ar)
    {
        this.area = ar;
    }
    public int getArea()
    {
        return area;
    }

    /**
     *
     * @return
     */
    @Override
    public String Dibujar() 
    {
        return "Nombre: Cuadrado";
    }
    
    
}
