
package Formas;


public abstract class Formas 
{
    private String color;
    
    public Formas ()
    {
       
    }
   
    public void EstablecerColor(String col)
    {
        this.color = col;
    }
    
    public String getColor()
    {
        return color;
    }
    
    public void ImprimirInformacion()
    {
        System.out.println(color);
    }
    
    abstract String Dibujar();
    
    
}
