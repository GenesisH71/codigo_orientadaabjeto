
package Formas;

public class Triangulo extends Formas 
{
    private int angulo;
    
    public Triangulo()
    {
        EstablecerColor("Color: Azul");
    }
    
    public void EstablecerAngulo(int ang)
    {
        this.angulo = ang;
    }
    
    public int getAngulo()
    {
        return angulo;
    }

    /**
     *
     * @return
     */
    @Override
    public String Dibujar() 
    {
        return "Nombre: Triangulo";
    }
    
}
