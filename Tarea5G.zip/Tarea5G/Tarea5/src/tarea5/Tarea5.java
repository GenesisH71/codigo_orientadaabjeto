
package tarea5;

import Formas.Circulo;
import Formas.Cuadrado;
import Formas.Linea;
import Formas.Triangulo;

public class Tarea5
{

    
    public static void main(String[] args) 
    {
       Circulo circulo = new Circulo();
        System.out.println("\n" + circulo.Dibujar());
        int diametro = 4;
        circulo.EstablecerRadio(diametro/2);
        System.out.println("Radio: " + circulo.getRadio());
        circulo.ImprimirInformacion();
        
       Linea linea = new Linea();
        System.out.println("\n"+linea.Dibujar());
        linea.EstablecerLargo("3");
        System.out.println("Largo: " + linea.getLargo() + " pulgadas");
       
       Triangulo triangulo = new Triangulo();
        System.out.println("\n" + triangulo.Dibujar());
        int a = 45, b = 45;
        int c = 180 - a - b;
        triangulo.EstablecerAngulo(c);
        System.out.println("Angulo: " + triangulo.getAngulo() + " Grados");
        triangulo.ImprimirInformacion();
        
       Cuadrado cuadrado = new Cuadrado();
        System.out.println("\n" + cuadrado.Dibujar());
        int s = 6;
        cuadrado.EstablecerArea(s*s);
        System.out.println("Area: " + cuadrado.getArea());
        cuadrado.ImprimirInformacion();
       
    }
    
}
