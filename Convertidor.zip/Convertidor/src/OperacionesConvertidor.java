
public class OperacionesConvertidor {
    private double n1,resultado;
    private int op1,opfinal;
    

    public double getN1() {
        return n1;
    }

    public void setN1(double n1) {
        this.n1 = n1;
    }

    public int getOp1() {
        return op1;
    }

    public void setOp1(int op1) {
        this.op1 = op1;
    }

    public int getOpfinal() {
        return opfinal;
    }

    public void setOpfinal(int opfinal) {
        this.opfinal = opfinal;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

    public OperacionesConvertidor() {
    }
    
    
    
    public double convertirLAD()
    {
        if (op1==0 && opfinal==1)
        {
            resultado = n1 * 0.041;
        }else if (op1==0 && opfinal == 0)
        {
            resultado = n1;
        }
        
       if (op1 == 1 && opfinal == 1)
       {
           resultado = n1;
       }else if(op1 == 1 && opfinal ==0)
       {
           resultado = n1 *24.19;
       }
        return resultado;
    }
    
}
